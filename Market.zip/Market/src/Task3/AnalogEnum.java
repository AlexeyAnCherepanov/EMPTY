package Task3;

/**

 Банкомат.
 Инициализируется набором купюр и умеет выдавать купюры для заданной суммы, либо отвечать отказом.
 При выдаче купюры списываются с баланса банкомата.
 Допустимые номиналы: 50₽, 100₽, 500₽, 1000₽, 5000₽.
 */
public class AnalogEnum {
    public static final int PENNY = 1;
    public static final int NICKLE = 5;
    public static final int DIME = 10;
    public static final int QUARTER = 25;

    private AnalogEnum() {
    } // Приватный конструктор для предотвращения создания экземпляров

    public static String getName(int currency) {
        switch (currency) {
            case PENNY:
                return "Penny";
            case NICKLE:
                return "Nickle";
            case DIME:
                return "Dime";
            case QUARTER:
                return "Quarter";
            default:
                return "Unknown";
        }
    }

    public static int[] getAllValues() {
        return new int[]{PENNY, NICKLE, DIME, QUARTER};
    }

    public static boolean isValidCurrency(int currency) {
        return currency == PENNY ||
                currency == NICKLE ||
                currency == DIME ||
                currency == QUARTER;
    }

    public static int getOrdinal(String name) {
        switch (name.toLowerCase()) {
            case "penny":
                return PENNY;
            case "nickle":
                return NICKLE;
            case "dime":
                return DIME;
            case "quarter":
                return QUARTER;
            default:
                throw new IllegalArgumentException("Invalid currency name");
        }
    }
}

