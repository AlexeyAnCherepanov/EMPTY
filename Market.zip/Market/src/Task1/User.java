package Task1;

public class User {
    public int id;
    public int discount;

    public User(int id, int discount) {
        this.id = id;
        this.discount = discount;
    }
}
